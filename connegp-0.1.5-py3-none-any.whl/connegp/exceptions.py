class ProfilesMediatypesException(ValueError):
    pass


class PagingError(ValueError):
    pass
